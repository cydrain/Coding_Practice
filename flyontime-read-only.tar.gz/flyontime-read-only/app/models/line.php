<?php
class Line extends AppModel
{
	var $name = 'Line';
}
?>