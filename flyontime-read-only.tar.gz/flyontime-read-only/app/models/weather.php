<?php
class Weather extends AppModel
{
	var $name = 'Weather';
	var $useTable = 'weather'; 
}
?>