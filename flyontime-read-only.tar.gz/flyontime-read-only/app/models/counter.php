<?php
class Counter extends AppModel
{
	var $name = 'Counter';
}
?>