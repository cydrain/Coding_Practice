<?php
class Ontime extends AppModel
{
	var $name = 'Ontime';
	var $useTable = 'ontime'; 
}
?>