<?php
class Enum extends AppModel
{
	var $name = 'Enum';
}
?>